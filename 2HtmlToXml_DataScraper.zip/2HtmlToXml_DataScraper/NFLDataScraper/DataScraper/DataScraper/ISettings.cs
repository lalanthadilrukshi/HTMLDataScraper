﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataScraper
{
    public class ISettings
    {
       

     
       
        public string DownLoadedFilesSavePath { get; set; }
        public int Process_Option { get; set; }

    }
}
